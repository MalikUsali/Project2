<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$reg_no= $_POST['reg_no'];
	$roll_no= $_POST['roll_no'];
	$first_name= $_POST['first_name'];
	$last_name= $_POST['last_name'];
	$session= $_POST['session'];
	$semester= $_POST['semester'];
	

$sql = "INSERT INTO course_registration (reg_no, roll_no, first_name,last_name,session,semester)
VALUES ('$reg_no', '$roll_no', '$first_name', '$last_name','$session','$semester')";

if (mysqli_query($conn, $sql)) {
    header('location:view_reg.php?insert=4');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    
}
}

?>