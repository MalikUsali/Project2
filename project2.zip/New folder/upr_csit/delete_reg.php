<?php
include "connection.php";

$id=$_GET['id'];

$sql = "DELETE FROM course_registration WHERE reg_no='$id'";

if (mysqli_query($conn, $sql)) {
   header("location:view_reg.php?delete=1");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>