<?php
include("connection.php");
$query = "SELECT * FROM course_registration";
$select  = mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Registration View</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<style>
		table{
			margin-top: 50px;
			background-color: lightgreen;
			color: white;
			border: solid black; 
			text-align: center;
			font-weight: bolder;
		}
		table tr{
			background-color: black;
		}
		table tr td{
			background-color: grey;
		}
		table a{
	        text-decoration: none;
       }
       
	</style>

</head>

<body>


          <!-- for Insertion + alert -->
<?php 
if ((isset($_GET['insert'])) && (isset($_GET['insert']))==4)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Inserted Successfully.
</div>
<?php }
?> 

	    <!-- for deletion + alert -->
<?php 
 if ((isset($_GET['delete'])) && (isset($_GET['delete']))==1)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Deleted Successfully.
</div>
<?php
}
?> 
          <!-- for updation + alert -->
<?php 
if ((isset($_GET['update'])) && (isset($_GET['update']))==2)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Updated Successfully.
</div>
<?php }
?> 



<table width="100%" align="center" border="solid" cellspacing="10px" cellpadding="5px" style="margin-bottom: 40px">
		<tr>
			<th>Reg No</th>
			<th>Roll No</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Session</th>
			<th>Semester</th>
			<th>Action</th>
			<th>Action</th>
		</tr>
<?php		
			if(mysqli_num_rows($select)>0)
			{
				while($row = mysqli_fetch_assoc($select)) {
				 
					?>
					<tr>
						<td><?php echo $row['reg_no']; ?></td>
						<td><?php echo $row['roll_no'] ?></td>
						<td><?php echo $row['first_name'] ?></td>
						<td><?php echo $row['last_name'] ?></td>
						<td><?php echo $row['session'] ?></td>
						<td><?php echo $row['semester'] ?></td>
						<td><a href="update_regf.php?id=<?php echo $row['reg_no'] ?>">Update</a></td>
						<td><a href="delete_reg.php?id=<?php echo $row['reg_no'] ?>">Delete</a></td>
					</tr>
					<?php

				}
			}

			 ?>
			
	</table>

 

</body>
</html>