<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$roll_no= $_POST['roll_no'];
	$first_name= $_POST['first_name'];
	$last_name= $_POST['last_name'];
	$session= $_POST['session'];
	$semester= $_POST['semester'];
	$id=$_POST['reg_no'];
	

$sql = "UPDATE course_registration SET  roll_no='$roll_no', first_name='$first_name', last_name='$last_name',session='$session',semester='$semester' WHERE reg_no='$id'";


if (mysqli_query($conn, $sql)) {
    header("location:view_reg.php?update=2");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

?>