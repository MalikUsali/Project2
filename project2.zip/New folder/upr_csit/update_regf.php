 <?php
  include("connection.php");
  $id= $_GET['id'];
  
$query = "SELECT * from course_registration where reg_no='$id'";
$select  = mysqli_query($conn,$query);
if(mysqli_num_rows($select)>0)
      {
       $row = mysqli_fetch_assoc($select);
     }

        ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Registeration Updates</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">

<style>

	body{
		background-color: grey;
	}
	form{
	border: 10px solid red;
	padding: 10px 10px;
	background: white;
	margin: 5px 10%;
}


</style>

</head>
<body>

<form method="POST" action="update_rg.php">
	<legend>Update Form</legend>

<div class="group">
	<label>Roll No &emsp;</label>
	<input type="number" name="roll_no" required="" value="<?php echo $row['roll_no'] ?>">
</div>

<div class="group">
	<label>First Name</label>
	<input type="text" name="first_name" required="" value="<?php echo $row['first_name'] ?>">
</div>

<div class="group">
	<label style="margin-right: 160px;">Last Name</label>
	<input type="text" name="last_name" required="" value="<?php echo $row['last_name'] ?>" >
</div>

<div class="group">
	<label style="margin-right: 200px;">Session</label>
	<input type="integer" name="session" required="" value="<?php echo $row['session'] ?>">
</div>

<div class="group">
	<label style="margin-right: 180px;">Semester</label>
	<input type="text" name="semester" required="" value="<?php echo $row['semester'] ?>">
</div>

<input type="text" name="reg_no" value="<?php echo $row['reg_no'] ?>" style="display: none;">

<div class="sub">
	<input type="submit" name="submit">
	<input type="reset" name="reset">
</div>


</form>

</body>
</html>